import { CrimeMap } from "@/components/crime-map"
import { PredictionForm } from "@/components/prediction-form"
import { TeamInfo } from "@/components/team-info"

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-gradient-to-r from-blue-800 to-blue-600 text-white p-6 shadow-md">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold">Guwahati Crime Prediction System</h1>
          <p className="mt-2 opacity-90">Real-time crime hotspot prediction to assist law enforcement</p>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4 text-blue-800">Predict Crime Hotspots</h2>
              <PredictionForm />
            </div>

            <div className="bg-white rounded-lg shadow-md p-6 mt-6">
              <h2 className="text-xl font-semibold mb-4 text-blue-800">Crime Statistics</h2>
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b pb-2">
                  <span className="font-medium">Total Predictions Today:</span>
                  <span className="text-blue-700 font-semibold">24</span>
                </div>
                <div className="flex justify-between items-center border-b pb-2">
                  <span className="font-medium">High Risk Areas:</span>
                  <span className="text-red-600 font-semibold">7</span>
                </div>
                <div className="flex justify-between items-center border-b pb-2">
                  <span className="font-medium">Most Common Crime:</span>
                  <span className="text-blue-700 font-semibold">Theft (IPC 379)</span>
                </div>
              </div>
            </div>

            <TeamInfo />
          </div>

          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-6 h-full">
              <h2 className="text-xl font-semibold mb-4 text-blue-800">Crime Hotspot Map</h2>
              <div className="h-[600px] w-full">
                <CrimeMap />
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-blue-900 text-white p-4 mt-8">
        <div className="container mx-auto text-center">
          <p>© 2025 Guwahati Crime Prediction System | Developed by Avayjeet Paul and Sagar Mazumder</p>
        </div>
      </footer>
    </div>
  )
}

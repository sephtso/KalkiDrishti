import { PredictionForm } from "@/components/prediction-form"
import { CrimeMap } from "@/components/crime-map"

export default function PredictionPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-gradient-to-r from-blue-800 to-blue-600 text-white p-6 shadow-md">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold">Crime Prediction</h1>
          <p className="mt-2 opacity-90">Generate and visualize crime predictions</p>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4 text-blue-800">Prediction Parameters</h2>
              <PredictionForm />
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-6 h-full">
              <h2 className="text-xl font-semibold mb-4 text-blue-800">Prediction Results</h2>
              <div className="h-[600px] w-full">
                <CrimeMap />
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-blue-900 text-white p-4 mt-8">
        <div className="container mx-auto text-center">
          <p>© 2025 Guwahati Crime Prediction System | Developed by Avayjeet Paul and Sagar Mazumder</p>
        </div>
      </footer>
    </div>
  )
}

import { NextResponse } from "next/server"
import type { CrimeStatistics } from "@/lib/types"

export async function GET() {
  try {
    // In a real application, this would fetch data from your database
    const statistics: CrimeStatistics = {
      totalPredictions: 24,
      highRiskAreas: 7,
      mostCommonCrime: "Theft (IPC 379)",
    }

    return NextResponse.json(statistics)
  } catch (error) {
    console.error("Error fetching statistics:", error)
    return NextResponse.json({ error: "Failed to fetch statistics" }, { status: 500 })
  }
}

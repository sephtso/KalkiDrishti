import { type NextRequest, NextResponse } from "next/server"
import type { CrimeHotspot } from "@/lib/types"

// This would be replaced with your actual ML model or API call
function predictCrimeHotspots(date: string, time: string, crimeType: string, radius: number): CrimeHotspot[] {
  // Sample prediction logic - in a real app, this would call your ML model
  const baseHotspots: CrimeHotspot[] = [
    {
      id: 1,
      lat: 26.1445,
      lng: 91.7362,
      risk: "high",
      crimeType: "Theft (IPC 379)",
      prediction: 0.87,
      incidents: 14,
    },
    {
      id: 2,
      lat: 26.1545,
      lng: 91.7662,
      risk: "medium",
      crimeType: "Assault (IPC 323)",
      prediction: 0.65,
      incidents: 8,
    },
    {
      id: 3,
      lat: 26.1345,
      lng: 91.7162,
      risk: "high",
      crimeType: "Theft (IPC 379)",
      prediction: 0.82,
      incidents: 12,
    },
    {
      id: 4,
      lat: 26.1645,
      lng: 91.7462,
      risk: "low",
      crimeType: "Rash Driving (IPC 279)",
      prediction: 0.45,
      incidents: 5,
    },
    {
      id: 5,
      lat: 26.1245,
      lng: 91.7562,
      risk: "medium",
      crimeType: "Kidnapping (IPC 363)",
      prediction: 0.58,
      incidents: 3,
    },
  ]

  // Filter by crime type if specified
  let filteredHotspots = baseHotspots
  if (crimeType !== "all") {
    const crimeTypeMap: Record<string, string> = {
      "379": "Theft (IPC 379)",
      "302": "Murder (IPC 302)",
      "363": "Kidnapping (IPC 363)",
      "323": "Assault (IPC 323)",
      "279": "Rash Driving (IPC 279)",
      "13": "Unlawful Assembly (IPC 13)",
    }

    filteredHotspots = baseHotspots.filter((hotspot) => hotspot.crimeType === crimeTypeMap[crimeType])
  }

  return filteredHotspots
}

export async function POST(request: NextRequest) {
  try {
    const { date, time, crimeType, radius } = await request.json()

    // Validate inputs
    if (!date || !time || !crimeType || radius === undefined) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    // Get predictions
    const predictions = predictCrimeHotspots(date, time, crimeType, radius)

    // Return predictions
    return NextResponse.json({ predictions })
  } catch (error) {
    console.error("Error in prediction API:", error)
    return NextResponse.json({ error: "Failed to generate prediction" }, { status: 500 })
  }
}

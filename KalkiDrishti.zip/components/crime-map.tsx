"use client"

import { useEffect, useRef, useState } from "react"
import { MapContainer, TileLayer, Circle, Popup, Marker } from "react-leaflet"
import "leaflet/dist/leaflet.css"
import { Icon } from "leaflet"
import { AlertTriangle, Info } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"

// Fix for Leaflet icon issue in Next.js
const markerIcon = new Icon({
  iconUrl: "/placeholder.svg?height=25&width=25",
  iconSize: [25, 25],
  iconAnchor: [12, 12],
})

// Sample crime hotspot data
const crimeHotspots = [
  {
    id: 1,
    lat: 26.1445,
    lng: 91.7362,
    risk: "high",
    crimeType: "Theft (IPC 379)",
    prediction: 0.87,
    incidents: 14,
  },
  {
    id: 2,
    lat: 26.1545,
    lng: 91.7662,
    risk: "medium",
    crimeType: "Assault (IPC 323)",
    prediction: 0.65,
    incidents: 8,
  },
  {
    id: 3,
    lat: 26.1345,
    lng: 91.7162,
    risk: "high",
    crimeType: "Theft (IPC 379)",
    prediction: 0.82,
    incidents: 12,
  },
  {
    id: 4,
    lat: 26.1645,
    lng: 91.7462,
    risk: "low",
    crimeType: "Rash Driving (IPC 279)",
    prediction: 0.45,
    incidents: 5,
  },
  {
    id: 5,
    lat: 26.1245,
    lng: 91.7562,
    risk: "medium",
    crimeType: "Kidnapping (IPC 363)",
    prediction: 0.58,
    incidents: 3,
  },
]

export function CrimeMap() {
  const mapRef = useRef(null)
  const [mapLoaded, setMapLoaded] = useState(false)

  useEffect(() => {
    // Fix for Leaflet rendering in Next.js
    setMapLoaded(true)
  }, [])

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "high":
        return "red"
      case "medium":
        return "orange"
      case "low":
        return "yellow"
      default:
        return "blue"
    }
  }

  const getRiskOpacity = (risk: string) => {
    switch (risk) {
      case "high":
        return 0.6
      case "medium":
        return 0.4
      case "low":
        return 0.2
      default:
        return 0.3
    }
  }

  if (!mapLoaded) {
    return <div className="h-full w-full flex items-center justify-center bg-gray-100">Loading map...</div>
  }

  return (
    <div className="h-full w-full relative">
      <div className="absolute top-2 right-2 z-10 bg-white p-2 rounded shadow-md">
        <div className="text-sm font-medium mb-1">Risk Level</div>
        <div className="flex items-center space-x-2 mb-1">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <span className="text-xs">High</span>
        </div>
        <div className="flex items-center space-x-2 mb-1">
          <div className="w-3 h-3 rounded-full bg-orange-500"></div>
          <span className="text-xs">Medium</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
          <span className="text-xs">Low</span>
        </div>
      </div>

      <MapContainer center={[26.1445, 91.7362]} zoom={13} style={{ height: "100%", width: "100%" }} ref={mapRef}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {crimeHotspots.map((hotspot) => (
          <Circle
            key={hotspot.id}
            center={[hotspot.lat, hotspot.lng]}
            radius={hotspot.risk === "high" ? 500 : hotspot.risk === "medium" ? 400 : 300}
            pathOptions={{
              fillColor: getRiskColor(hotspot.risk),
              fillOpacity: getRiskOpacity(hotspot.risk),
              color: getRiskColor(hotspot.risk),
              weight: 1,
            }}
          >
            <Popup>
              <Card className="border-0 shadow-none">
                <CardContent className="p-2">
                  <div className="flex items-start space-x-2">
                    {hotspot.risk === "high" ? (
                      <AlertTriangle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                    ) : (
                      <Info className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
                    )}
                    <div>
                      <h3 className="font-medium text-sm">{hotspot.crimeType}</h3>
                      <div className="mt-1 space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span className="text-gray-500">Risk Level:</span>
                          <Badge
                            variant={
                              hotspot.risk === "high"
                                ? "destructive"
                                : hotspot.risk === "medium"
                                  ? "warning"
                                  : "outline"
                            }
                          >
                            {hotspot.risk.charAt(0).toUpperCase() + hotspot.risk.slice(1)}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Prediction Score:</span>
                          <span className="font-medium">{(hotspot.prediction * 100).toFixed(0)}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Historical Incidents:</span>
                          <span className="font-medium">{hotspot.incidents}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Popup>
          </Circle>
        ))}

        {/* Central marker for Guwahati */}
        <Marker position={[26.1445, 91.7362]} icon={markerIcon}>
          <Popup>
            <div className="text-sm font-medium">Guwahati City Center</div>
          </Popup>
        </Marker>
      </MapContainer>
    </div>
  )
}

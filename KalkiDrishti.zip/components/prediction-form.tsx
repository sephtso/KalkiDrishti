"use client"

import type React from "react"

import { useState } from "react"
import { Calendar, Clock, Filter, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"

export function PredictionForm() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [time, setTime] = useState("12:00")
  const [crimeType, setCrimeType] = useState("all")
  const [radius, setRadius] = useState([2])
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call for prediction
    setTimeout(() => {
      setIsLoading(false)
      // Here you would typically update the map with new predictions
      alert("Prediction generated! Map updated with new hotspots.")
    }, 1500)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="date">Date</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="w-full justify-start text-left font-normal" id="date">
              <Calendar className="mr-2 h-4 w-4" />
              {date ? date.toLocaleDateString() : "Select date"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <CalendarComponent mode="single" selected={date} onSelect={setDate} initialFocus />
          </PopoverContent>
        </Popover>
      </div>

      <div className="space-y-2">
        <Label htmlFor="time">Time</Label>
        <div className="flex items-center space-x-2">
          <Clock className="h-4 w-4 text-gray-500" />
          <Input id="time" type="time" value={time} onChange={(e) => setTime(e.target.value)} className="flex-1" />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="crime-type">Crime Type</Label>
        <Select value={crimeType} onValueChange={setCrimeType}>
          <SelectTrigger id="crime-type">
            <SelectValue placeholder="Select crime type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Crimes</SelectItem>
            <SelectItem value="379">Theft (IPC 379)</SelectItem>
            <SelectItem value="302">Murder (IPC 302)</SelectItem>
            <SelectItem value="363">Kidnapping (IPC 363)</SelectItem>
            <SelectItem value="323">Assault (IPC 323)</SelectItem>
            <SelectItem value="279">Rash Driving (IPC 279)</SelectItem>
            <SelectItem value="13">Unlawful Assembly (IPC 13)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between">
          <Label htmlFor="radius">Search Radius (km)</Label>
          <span className="text-sm text-gray-500">{radius[0]} km</span>
        </div>
        <Slider id="radius" min={1} max={10} step={1} value={radius} onValueChange={setRadius} />
      </div>

      <div className="pt-2">
        <Button type="submit" className="w-full bg-blue-700 hover:bg-blue-800" disabled={isLoading}>
          {isLoading ? (
            <>
              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
              Generating Prediction...
            </>
          ) : (
            <>
              <Search className="mr-2 h-4 w-4" />
              Generate Prediction
            </>
          )}
        </Button>
      </div>

      {crimeType !== "all" && (
        <Card className="mt-4 bg-blue-50">
          <CardContent className="p-4">
            <h3 className="font-medium text-blue-800 flex items-center">
              <Filter className="h-4 w-4 mr-2" />
              Active Filter
            </h3>
            <p className="text-sm text-gray-600 mt-1">
              Showing predictions for:{" "}
              {crimeType === "379"
                ? "Theft (IPC 379)"
                : crimeType === "302"
                  ? "Murder (IPC 302)"
                  : crimeType === "363"
                    ? "Kidnapping (IPC 363)"
                    : crimeType === "323"
                      ? "Assault (IPC 323)"
                      : crimeType === "279"
                        ? "Rash Driving (IPC 279)"
                        : "Unlawful Assembly (IPC 13)"}
            </p>
          </CardContent>
        </Card>
      )}
    </form>
  )
}

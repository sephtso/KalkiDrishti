import { Users } from "lucide-react"

export function TeamInfo() {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mt-6">
      <h2 className="text-xl font-semibold mb-4 text-blue-800 flex items-center">
        <Users className="mr-2 h-5 w-5" />
        Project Team
      </h2>
      <div className="space-y-4">
        <div className="flex items-center space-x-3">
          <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-semibold">
            AP
          </div>
          <div>
            <p className="font-medium">Avayjeet Paul</p>
            <p className="text-sm text-gray-500">Lead Developer</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-semibold">
            SM
          </div>
          <div>
            <p className="font-medium">Sagar Mazumder</p>
            <p className="text-sm text-gray-500">Data Scientist</p>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t">
          <p className="text-sm text-gray-600">
            This project was developed to assist Guwahati Police in predicting and preventing crime through advanced
            machine learning algorithms and data visualization.
          </p>
        </div>
      </div>
    </div>
  )
}

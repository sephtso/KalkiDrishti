export interface CrimeHotspot {
  id: number
  lat: number
  lng: number
  risk: "high" | "medium" | "low"
  crimeType: string
  prediction: number
  incidents: number
}

export interface PredictionParams {
  date: Date
  time: string
  crimeType: string
  radius: number
}

export interface CrimeStatistics {
  totalPredictions: number
  highRiskAreas: number
  mostCommonCrime: string
}
